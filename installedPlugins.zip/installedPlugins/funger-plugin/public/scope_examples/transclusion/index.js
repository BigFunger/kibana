define(function (require) {

  require('ui/routes')
  .when('/scope_examples/transclusion', {
    template: require('plugins/funger-plugin/scope_examples/transclusion/index.html'),
    controller: function($scope) {
      $scope.answers = { baseLocation: 'Yavin 4' }
    }
  });

  var app = require('ui/modules').get('app/scope_examples', []);

  app.directive('myQuestion', function() {
    return {
      restrict: 'E',
      transclude: true,
      template: require('plugins/funger-plugin/scope_examples/transclusion/myQuestion.html'),
      scope: {
        questionText: '@q'
      }
    }
  })
});
