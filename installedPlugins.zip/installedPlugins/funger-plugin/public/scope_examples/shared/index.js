define(function (require) {
  require('plugins/funger-plugin/scope_examples/shared/user-info-card');

  require('ui/routes')
  .when('/scope_examples/shared', {
    template: require('plugins/funger-plugin/scope_examples/shared/index.html'),
    controller: function($scope) {
      $scope.primitive = 'old value';

      $scope.user = {
        name: 'Luke Skywalker',
        address: {
          street: 'PO Box 123',
          city: 'Secret Rebel Base',
          planet: 'Yavin 4'
        },
        friends: [
          'Han',
          'Leia',
          'Chewbacca'
        ]
      };

      console.log('parent scope', $scope);
    }
  });
});
