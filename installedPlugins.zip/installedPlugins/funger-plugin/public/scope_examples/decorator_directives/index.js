define(function (require) {

  require('ui/routes')
  .when('/scope_examples/decorator_directives', {
    template: require('plugins/funger-plugin/scope_examples/decorator_directives/index.html'),
    controller: function($scope) {
      $scope.messages = [];

      $scope.handlePauseIsolate = function() {
        $scope.messages.push({ text: 'paused!' });
        console.log('video was paused!');
      }

      $scope.handlePause = function(e) {
        console.log(e);
        $scope.messages.push({ text: 'paused!' });
        console.log('video was paused!');
      }
    }
  });

  var app = require('ui/modules').get('app/scope_examples', []);

  //This first implementation works. HOWEVER, it relies on an isolate scope. This is bad because there can not be more than on directive on an element that requires an isolate scope. Angular will not allow it.
  /*
  app.directive('eventPauseIsolate', function() {
    return {
      restrict: 'A',
      scope: {
        eventPauseIsolate: '&'
      },
      link: function(scope, ele, attr) {
        //this external event happens outside of angular's digest cycle.
        ele.on('pause', function(event) {
          //we need to inject something into angular's digest cycle, so we use scope.$apply.
          scope.$apply(function() {
            //we call the function from the isolate scope.
            scope.eventPause();
          });
        });
      }
    };
  });
*/

  app.directive('eventPause', function($parse) {
    return {
      restrict: 'A',
      link: function(scope, ele, attr) {
        //Since we are no longer using an isolate scope, we need to access the event-pause attribute on the object.
        //However, if we just access the value of that attribute we will just get the string value of it, and not a refence to the function defined on the parent scope. For that, we need to use angular's $parse service.
        var fn = $parse(attr['eventPause']);

        //this external event happens outside of angular's digest cycle.
        ele.on('pause', function(event) {
          //we need to inject something into angular's digest cycle, so we use scope.$apply.
          scope.$apply(function() {
            //we call the function from the $parse service.
            fn(scope, { evt: event });
          });
        });
      }
    };
  });

  app.directive('spacebarSupport', function () {
    return {
      restrict: 'A',
      // We use the link property when we want to modify elements in the dom.
      link: function(scope, ele, attr) {
        //scope - the scope object
        //ele - the element that this attribute belongs to
        //attr - an array of all of the attributes on that element

        var video = ele[0];
        $('body').on('keypress', function(event) {
          //keycode 32 = spacebar
          if(event.keyCode === 32) {
            if (video.paused) {
              video.play();
            } else {
              video.pause();
            }
          }
        });
      }
    };
  });

  //as a shorthand, for attribute directives, you can just return the link function instead of a directive object, and it will work the same, and assume the defaults.
  app.directive('pPlaySupport', function() {
    return function(scope, ele, attr) {
      //scope - the scope object
      //ele - the element that this attribute belongs to
      //attr - an array of all of the attributes on that element

      var video = ele[0];
      $('body').on('keypress', function(event) {
        //keycode 32 = p
        if(event.keyCode === 112) {
          if (video.paused) {
            video.play();
          } else {
            video.pause();
          }
        }
      });
    };
  });
});
