define(function (require) {

  require('ui/routes')
  .when('/scope_examples/custom_ng_click', {
    template: require('plugins/funger-plugin/scope_examples/custom_ng_click/index.html'),
    controller: function($scope) {
      $scope.data = { message: 'I have not been clicked' };
      $scope.clickHandler = function(p) {
        p.message = 'I HAVE been clicked';
      }
    }
  });

  var app = require('ui/modules').get('app/scope_examples', []);

  app.directive('myClick', function($parse) {
    return {
      restrict: 'A',
      link: function(scope, ele, attr) {
        var fn = $parse(attr['myClick']);

        ele.on('click', function() {
          scope.$apply(function() {
            fn(scope);
          });
        });
      }
    };
  });
});
