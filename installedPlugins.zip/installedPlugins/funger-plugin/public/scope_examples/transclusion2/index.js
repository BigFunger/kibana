define(function (require) {
  require('plugins/funger-plugin/scope_examples/transclusion2/index.less');

  require('ui/routes')
  .when('/scope_examples/transclusion2', {
    template: require('plugins/funger-plugin/scope_examples/transclusion2/index.html'),
    controller: function($scope) {
      $scope.person1 = {
        name: 'Luke Skywalker',
        address: {
          street: 'PO Box 123',
          city: 'Secret Rebel Base',
          planet: 'Yavin 4'
        },
        friends: [
          'Han',
          'Leia',
          'Chewbacca'
        ],
        state: 1
      };

      $scope.person2 = {
        name: 'Han Solo',
        address: {
          street: 'PO Box 123',
          city: 'Moss Isley',
          planet: 'Tatooine'
        },
        friends: [
          'Luke',
          'Leia',
          'Chewbacca'
        ],
        state: 2
      };

      $scope.droid1 = {
        name: 'R2D2',
        specifications: {
          manufacturer: 'Mas Homemade Robots',
          type: 'Astromech',
          productLine: 'R2'
        },
        state: 3
      };
    }
  });

  var app = require('ui/modules').get('app/scope_examples', []);

  app.directive('userPanel', function() {
    return {
      restrict: 'E',
      transclude: true,
      template: require('plugins/funger-plugin/scope_examples/transclusion2/user-panel.html'),
      scope: {
        name: '@',
        state: '=',
        collapsed: '@'
      },
      controller: function($scope) {
        $scope.collapsed = !!$scope.collapsed;

        $scope.collapse = function() {
          $scope.collapsed = !$scope.collapsed;
        }

        $scope.nextState = function(event) {
          event.stopPropagation();
          event.preventDefault();
          $scope.state += 1;
          $scope.state = $scope.state % 4;
        }
      }
    }
  });

  app.directive('personInfoCard', function () {
    return {
      restrict: 'E',
      scope: {
        person: '=person',
        collapsed: '@'
      },
      template: require('plugins/funger-plugin/scope_examples/transclusion2/person-info-card.html'),
      controller: function($scope) {
        $scope.knightMe = function(person) {
          person.rank = 'knight';
        }

        $scope.removeFriend = function(friend) {
          var idx = $scope.person.friends.indexOf(friend);
          if (idx > -1) {
            $scope.person.friends.splice(idx, 1);
          }
        }
      }
    };
  });

  app.directive('droidInfoCard', function () {
    return {
      restrict: 'E',
      scope: {
        droid: '=droid',
        collapsed: '@'
      },
      template: require('plugins/funger-plugin/scope_examples/transclusion2/droid-info-card.html'),
      controller: function($scope) {
      }
    };
  });

  app.directive('removeFriend2', function() {
    return {
      restrict: 'E',
      scope: {
        notifyParent: '&method'
      },
      template: require('plugins/funger-plugin/scope_examples/transclusion2/remove-friend.html'),
      controller: function($scope) {
        $scope.removing = false;
        $scope.startRemove = function() {
          $scope.removing = true;
        }
        $scope.cancelRemove = function() {
          $scope.removing = false;
        }
        $scope.confirmRemove = function() {
          $scope.notifyParent();
        }
      }
    }
  });

  app.directive('levelDisplay', function() {
    return {
      link: function(scope, ele, attr) {
        var parms = attr['levelDisplay'].split(' ');
        var linkVar = parms[0];
        parms.splice(0, 1);
        classes = parms;
        var classList = classes.join(' ');

        scope.$watch(linkVar, function(newVal) {
          ele.removeClass(classList);
          ele.addClass(classes[newVal]);
        });
      }
    }
  });

});
