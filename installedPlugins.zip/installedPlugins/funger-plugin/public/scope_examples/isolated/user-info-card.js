define(function (require) {
  var app = require('ui/modules').get('app/scope_examples', []);

  app.directive('userInfoCardIsolated', function () {
    return {
      restrict: 'E',
      scope: {
        user: '=person', // the = sign indicates that this is bound to the specified property on the parent scope. This says: "In this isolated scope, there will be a property named user. In the markup where this directive is being used, there will be an attribute named person. Whatever value is in that attribute will refer to a property on the parent's scope."
        collapsed: '@' // the @ sign indicates a simple string value being passed in.
      },
      template: require('plugins/funger-plugin/scope_examples/isolated/user-info-card.html'),
      controller: function($scope) {
        $scope.primitive = 'new value';
        $scope.collapsed = !!$scope.collapsed;

        $scope.knightMe = function(user) {
          user.rank = 'knight';
        }

        $scope.collapse = function() {
          $scope.collapsed = !$scope.collapsed;
        }

        $scope.removeFriend = function(friend) {
          var idx = $scope.user.friends.indexOf(friend);
          if (idx > -1) {
            $scope.user.friends.splice(idx, 1);
          }
        }

        console.log('userInfoCardIsolated scope', $scope);
      }
    };
  });

  //because this is a shared scope, it shares the parent's scope. In this case, the isolated scope of the ng-repeat
  //directive.
  app.directive('removeFriend', function() {
    return {
      restrict: 'E',
      scope: {
        notifyParent: '&method'
      },
      template: require('plugins/funger-plugin/scope_examples/isolated/remove-friend.html'),
      controller: function($scope) {
        $scope.removing = false;
        $scope.startRemove = function() {
          $scope.removing = true;
        }
        $scope.cancelRemove = function() {
          $scope.removing = false;
        }
        $scope.confirmRemove = function() {
          $scope.notifyParent();
          //This is a wrapper for the function call defined in the markup. In our example removeFriend(friend). This works the same way that ng-click is used.
        }
        $scope.trickyConfirmRemove = function() {
          //This will override the value that is passed in in the markup with the value that I provide.
          $scope.notifyParent({ friend: 'Han' });
        }

        console.log('removeFriend scope', $scope);
      }
    }
  });

  //since this is an isolated scope directive, and we are already defining an isolated scope for the user-info-card-isolated directive, the browser will throw an error if we add this directive to that node.
  app.directive('myDirective', function () {
    scope: {}
  });
});
