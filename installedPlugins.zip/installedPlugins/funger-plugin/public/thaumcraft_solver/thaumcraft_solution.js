  var app = require('ui/modules').get('app/thaumcraft_solver', []);

  //This is going to use shared scope.
  //I don't think we even need a controller.
  //This isn't very useful
  app.directive('thaumcraftSolutionSharedScope', function () {
    return {
      restrict: 'E',
      template: require('plugins/funger-plugin/thaumcraft_solver/thaumcraft_solution.html')
      // ,
      // controller: function ($scope) {
      //   var _ = require('lodash');

      //   require('plugins/funger-plugin/thaumcraft_solver/solver.less');
      //   var aspects = $scope.aspects = require('plugins/funger-plugin/thaumcraft_solver/aspects');
      //   var findResult = require('plugins/funger-plugin/thaumcraft_solver/solver');

      //   $scope.filteredAspects = _.filter(aspects, function(aspect) { return aspect.name != 'dummy'; });

      //   $scope.sourceAspect = '';
      //   $scope.targetAspect = '';
      //   $scope.iterations = 1;

      //   $scope.$watch('sourceAspect', generateResult);
      //   $scope.$watch('targetAspect', generateResult);
      //   $scope.$watch('iterations', generateResult);

      //   function generateResult(newVal, oldVal) {
      //     $scope.result = '';

      //     if (!$scope.sourceAspect) return;
      //     if (!$scope.targetAspect) return;

      //     $scope.result = findResult($scope.sourceAspect.name, $scope.targetAspect.name, $scope.iterations);
      //   }

      //   $scope.getBackgroundPosition = function(aspect) {
      //     var index = $scope.aspects.indexOf(aspect);
      //     var yIndex = Math.floor(index / 8);
      //     var xIndex = index % 8;

      //     var x = -1 * (xIndex*64) - 4;
      //     var y = -1 * (yIndex*64) - 4;

      //     return `${x}px ${y}px`;
      //   }

      // }
    };
  });


  app.directive('thaumcraftSolutionIsolateScope', function () {
    return {
      restrict: 'E',
      scope: {
        result: '='
      },
      template: require('plugins/funger-plugin/thaumcraft_solver/thaumcraft_solution.html'),
      controller: function ($scope) {
        var aspects = $scope.aspects = require('plugins/funger-plugin/thaumcraft_solver/aspects');

        $scope.getBackgroundPosition = function(aspect) {
          var index = $scope.aspects.indexOf(aspect);
          var yIndex = Math.floor(index / 8);
          var xIndex = index % 8;

          var x = -1 * (xIndex*64) - 4;
          var y = -1 * (yIndex*64) - 4;

          return `${x}px ${y}px`;
        }
      }
    };
  });
