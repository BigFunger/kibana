// highlight color: #E9478C

require('ui/chrome')
.setBrand({
  logo: 'url(/plugins/k4-plugin-dancing-bear/logo.png) center no-repeat',
  smallLogo: 'url(/plugins/k4-plugin-dancing-bear/logo.png) center no-repeat',
})
.setNavBackground('#39BDB1')
.setTabDefaults({
  activeIndicatorColor: '#E9478C'
})
.setTabs([
  {
    id: '',
    title: 'Much Dance'
  }
])
.setRootTemplate(require('plugins/k4-plugin-dancing-bear/main.html'));
