Dancing bear plugin for [Kibana](https://github.com/elastic/kibana) >= 4.2.0

Installation:
`$ bin/kibana plugin -i w33ble/k4-plugin-dancing-bear`
